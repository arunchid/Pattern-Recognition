import cv2
import matplotlib.pyplot as plt
import numpy as np
import utils
import os
from sklearn.cluster import KMeans
import pandas as pd
#import pytesseract as tess
import random
import datetime

list_objects = []
for file in os.listdir(utils.IMAGES_PATH):
    filename = file
    name_strip = [filename[:-4]]
    file = f"{utils.IMAGES_PATH}/{file}"
    if file.endswith(".jpg"):
        m = plt.imread(file)
        #img = Image.open(file)
        #text = tess.image_to_string(m)
        #texts = file
        # print(text)
        # Added by Arun on 20/12/2020
        # m = m[80:250, 15:520]
        original = m
        plt.imshow(original)
        plt.show()
        rgb = cv2.cvtColor(m, cv2.COLOR_LUV2RGB)
        gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
        # plt.imshow(gray)
        # plt.show()
        # TODO tune the 150 to better reflect the problem
        _, thresh = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)
        # plt.imshow(thresh)
        # plt.show()

        contours, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(m, contours, -1, (0, 0, 255), 3)
        plt.imshow(m)
        plt.show()

        # Added by Arun on 20/12/2020
        average = m.mean(axis=0).mean(axis=0)

        pixels = np.float32(m.reshape(-1, 3))

        n_colors = 5
        criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 200, .1)
        flags = cv2.KMEANS_RANDOM_CENTERS

        _, labels, palette = cv2.kmeans(pixels, n_colors, None, criteria, 10, flags)
        _, counts = np.unique(labels, return_counts=True)
       # numLabels = np.arange(0, len(np.unique(clt.labels_)) + 1)

        dominant = palette[np.argmax(counts)]
        # print(average)
        #print(dominant)

        name_strip = name_strip

        center = np.uint8(counts)
        center = np.sort(center)
        Cluster_Label = center[-1]
        strip_name_List = []
        strip_name_List.append([name_strip])
        # print(strip_name_List, dominant, Cluster_Label)

        strip_string = strip_name_List[0]
        strip = strip_string[0]
        strip_str = strip[0].split(' ', 1)
        date_time_obj = datetime.datetime.strptime(strip_str[1], '%d-%b-%Y %H.%M.%S')
        output = {
            'Date': date_time_obj,
            'Red': dominant[0],
            'Green': dominant[1],
            'Blue': dominant[2],
            'Cluster Label': Cluster_Label
        }

        list_objects.append(output)

Data = pd.DataFrame(list_objects)
print(Data)
Data.to_csv('Image_Classification.csv')











